import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-menudriver',
  templateUrl: './menudriver.page.html',
  styleUrls: ['./menudriver.page.scss'],
})
export class MenudriverPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
