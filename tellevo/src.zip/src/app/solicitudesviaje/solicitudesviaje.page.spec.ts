import { ComponentFixture, TestBed } from '@angular/core/testing';
import { SolicitudesviajePage } from './solicitudesviaje.page';

describe('SolicitudesviajePage', () => {
  let component: SolicitudesviajePage;
  let fixture: ComponentFixture<SolicitudesviajePage>;

  beforeEach(() => {
    fixture = TestBed.createComponent(SolicitudesviajePage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
